# Nearby
A simple Android app to show you recommendations of places to go near your current location
