package xyz.marcb.foursquare.data;

public class Venue {
    public String name;
    public Location location;
}
