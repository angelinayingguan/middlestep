package xyz.marcb.foursquare.data;

public class Location {
    public Double lat;
    public Double lng;
}
